/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Nov 12, 2020, 10:01:25 AM                   ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.spartacussampledataaddon.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedSpartacussampledataaddonConstants
{
	public static final String EXTENSIONNAME = "spartacussampledataaddon";
	
	protected GeneratedSpartacussampledataaddonConstants()
	{
		// private constructor
	}
	
	
}
