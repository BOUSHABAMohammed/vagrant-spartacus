/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.b2bpunchoutaddon.controllers.pages;

import org.springframework.stereotype.Controller;


@Controller
public interface PunchOutController
{
	//add methods common to all punchOutController.
}
