/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.commerceorgsamplesaddon.controllers;

/**
 */
public interface CommerceorgsamplesaddonControllerConstants
{
	// implement here controller constants used by this extension
}
