/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.acceleratorstorefrontcommons.forms;


public class StoreFinderForm
{
	private String q;

	public String getQ()
	{
		return q;
	}

	public void setQ(final String q)
	{
		this.q = q;
	}
}
